# -*- coding: utf-8 -*-
from flask import Flask, render_template, request, redirect, url_for, session, g, flash
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os

DB_PATH = "lms.db"

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "CHANGE-ME-IN-PROD")

# --- DB helpers ---
def get_db():
    if "db" not in g:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        g.db = conn
    return g.db

@app.teardown_appcontext
def close_db(exception):
    db = g.pop("db", None)
    if db is not None:
        db.close()

# --- Auth helpers ---
def login_required(view):
    from functools import wraps
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            return redirect(url_for("dashboard"))
        flash("Usuario o contraseña incorrectos", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# --- Dashboard ---
@app.route("/")
@login_required
def dashboard():
    db = get_db()
    counts = {
        "users": db.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"],
        "alumnos": db.execute("SELECT COUNT(*) AS c FROM alumnos").fetchone()["c"],
        "profesores": db.execute("SELECT COUNT(*) AS c FROM profesores").fetchone()["c"],
        "cursos": db.execute("SELECT COUNT(*) AS c FROM cursos").fetchone()["c"],
        "asignaturas": db.execute("SELECT COUNT(*) AS c FROM asignaturas").fetchone()["c"],
        "materiales": db.execute("SELECT COUNT(*) AS c FROM materiales").fetchone()["c"],
    }
    return render_template("dashboard.html", counts=counts)

# --- Usuarios (solo admin básico) ---
@app.route("/admin/usuarios")
@login_required
def usuarios_list():
    db = get_db()
    users = db.execute("SELECT id, username, role, created_at FROM users ORDER BY id DESC").fetchall()
    return render_template("usuarios_list.html", users=users)

@app.route("/admin/usuarios/nuevo", methods=["GET","POST"])
@login_required
def usuarios_nuevo():
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"]
        role = request.form.get("role","admin")
        db = get_db()
        try:
            db.execute("INSERT INTO users (username, password_hash, role, created_at) VALUES (?,?,?,?)",
                       (username, generate_password_hash(password), role, datetime.utcnow().isoformat()))
            db.commit()
            return redirect(url_for("usuarios_list"))
        except sqlite3.IntegrityError:
            flash("El usuario ya existe.", "error")
    return render_template("usuarios_form.html", user=None)

@app.route("/admin/usuarios/<int:user_id>/resetpass", methods=["POST"])
@login_required
def usuarios_resetpass(user_id):
    newpass = request.form.get("newpass","")
    if not newpass:
        flash("Proporciona una nueva contraseña", "error")
        return redirect(url_for("usuarios_list"))
    db = get_db()
    db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(newpass), user_id))
    db.commit()
    flash("Contraseña actualizada.", "ok")
    return redirect(url_for("usuarios_list"))

@app.route("/admin/usuarios/<int:user_id>/eliminar", methods=["POST"])
@login_required
def usuarios_eliminar(user_id):
    db = get_db()
    db.execute("DELETE FROM users WHERE id=?", (user_id,))
    db.commit()
    return redirect(url_for("usuarios_list"))

# --- CRUD genérico simple para entidades base ---

# Alumnos
@app.route("/admin/alumnos")
@login_required
def alumnos_list():
    db = get_db()
    items = db.execute("SELECT * FROM alumnos ORDER BY id DESC").fetchall()
    return render_template("alumnos_list.html", items=items)

@app.route("/admin/alumnos/nuevo", methods=["GET","POST"])
@login_required
def alumnos_nuevo():
    if request.method == "POST":
        nombre = request.form["nombre"].strip()
        apellidos = request.form["apellidos"].strip()
        email = request.form.get("email","").strip() or None
        db = get_db()
        try:
            db.execute("INSERT INTO alumnos (nombre, apellidos, email) VALUES (?,?,?)", (nombre, apellidos, email))
            db.commit()
            return redirect(url_for("alumnos_list"))
        except sqlite3.IntegrityError:
            flash("Email duplicado.", "error")
    return render_template("alumnos_form.html", item=None)

@app.route("/admin/alumnos/<int:item_id>/editar", methods=["GET","POST"])
@login_required
def alumnos_editar(item_id):
    db = get_db()
    item = db.execute("SELECT * FROM alumnos WHERE id=?", (item_id,)).fetchone()
    if not item:
        return redirect(url_for("alumnos_list"))
    if request.method == "POST":
        nombre = request.form["nombre"].strip()
        apellidos = request.form["apellidos"].strip()
        email = request.form.get("email","").strip() or None
        try:
            db.execute("UPDATE alumnos SET nombre=?, apellidos=?, email=? WHERE id=?", (nombre, apellidos, email, item_id))
            db.commit()
            return redirect(url_for("alumnos_list"))
        except sqlite3.IntegrityError:
            flash("Email duplicado.", "error")
    return render_template("alumnos_form.html", item=item)

@app.route("/admin/alumnos/<int:item_id>/eliminar", methods=["POST"])
@login_required
def alumnos_eliminar(item_id):
    db = get_db()
    db.execute("DELETE FROM alumnos WHERE id=?", (item_id,))
    db.commit()
    return redirect(url_for("alumnos_list"))

# Profesores
@app.route("/admin/profesores")
@login_required
def profesores_list():
    db = get_db()
    items = db.execute("SELECT * FROM profesores ORDER BY id DESC").fetchall()
    return render_template("profesores_list.html", items=items)

@app.route("/admin/profesores/nuevo", methods=["GET","POST"])
@login_required
def profesores_nuevo():
    if request.method == "POST":
        nombre = request.form["nombre"].strip()
        apellidos = request.form["apellidos"].strip()
        email = request.form.get("email","").strip() or None
        db = get_db()
        try:
            db.execute("INSERT INTO profesores (nombre, apellidos, email) VALUES (?,?,?)", (nombre, apellidos, email))
            db.commit()
            return redirect(url_for("profesores_list"))
        except sqlite3.IntegrityError:
            flash("Email duplicado.", "error")
    return render_template("profesores_form.html", item=None)

@app.route("/admin/profesores/<int:item_id>/editar", methods=["GET","POST"])
@login_required
def profesores_editar(item_id):
    db = get_db()
    item = db.execute("SELECT * FROM profesores WHERE id=?", (item_id,)).fetchone()
    if not item:
        return redirect(url_for("profesores_list"))
    if request.method == "POST":
        nombre = request.form["nombre"].strip()
        apellidos = request.form["apellidos"].strip()
        email = request.form.get("email","").strip() or None
        try:
            db.execute("UPDATE profesores SET nombre=?, apellidos=?, email=? WHERE id=?", (nombre, apellidos, email, item_id))
            db.commit()
            return redirect(url_for("profesores_list"))
        except sqlite3.IntegrityError:
            flash("Email duplicado.", "error")
    return render_template("profesores_form.html", item=item)

@app.route("/admin/profesores/<int:item_id>/eliminar", methods=["POST"])
@login_required
def profesores_eliminar(item_id):
    db = get_db()
    db.execute("DELETE FROM profesores WHERE id=?", (item_id,))
    db.commit()
    return redirect(url_for("profesores_list"))

# Cursos
@app.route("/admin/cursos")
@login_required
def cursos_list():
    db = get_db()
    items = db.execute("SELECT * FROM cursos ORDER BY id DESC").fetchall()
    return render_template("cursos_list.html", items=items)

@app.route("/admin/cursos/nuevo", methods=["GET","POST"])
@login_required
def cursos_nuevo():
    if request.method == "POST":
        nombre = request.form["nombre"].strip()
        descripcion = request.form.get("descripcion","").strip() or None
        db = get_db()
        db.execute("INSERT INTO cursos (nombre, descripcion) VALUES (?,?)", (nombre, descripcion))
        db.commit()
        return redirect(url_for("cursos_list"))
    return render_template("cursos_form.html", item=None)

@app.route("/admin/cursos/<int:item_id>/editar", methods=["GET","POST"])
@login_required
def cursos_editar(item_id):
    db = get_db()
    item = db.execute("SELECT * FROM cursos WHERE id=?", (item_id,)).fetchone()
    if not item:
        return redirect(url_for("cursos_list"))
    if request.method == "POST":
        nombre = request.form["nombre"].strip()
        descripcion = request.form.get("descripcion","").strip() or None
        db.execute("UPDATE cursos SET nombre=?, descripcion=? WHERE id=?", (nombre, descripcion, item_id))
        db.commit()
        return redirect(url_for("cursos_list"))
    return render_template("cursos_form.html", item=item)

@app.route("/admin/cursos/<int:item_id>/eliminar", methods=["POST"])
@login_required
def cursos_eliminar(item_id):
    db = get_db()
    db.execute("DELETE FROM cursos WHERE id=?", (item_id,))
    db.commit()
    return redirect(url_for("cursos_list"))

# Asignaturas
@app.route("/admin/asignaturas")
@login_required
def asignaturas_list():
    db = get_db()
    items = db.execute("SELECT * FROM asignaturas ORDER BY id DESC").fetchall()
    return render_template("asignaturas_list.html", items=items)

@app.route("/admin/asignaturas/nuevo", methods=["GET","POST"])
@login_required
def asignaturas_nuevo():
    if request.method == "POST":
        nombre = request.form["nombre"].strip()
        descripcion = request.form.get("descripcion","").strip() or None
        db = get_db()
        db.execute("INSERT INTO asignaturas (nombre, descripcion) VALUES (?,?)", (nombre, descripcion))
        db.commit()
        return redirect(url_for("asignaturas_list"))
    return render_template("asignaturas_form.html", item=None)

@app.route("/admin/asignaturas/<int:item_id>/editar", methods=["GET","POST"])
@login_required
def asignaturas_editar(item_id):
    db = get_db()
    item = db.execute("SELECT * FROM asignaturas WHERE id=?", (item_id,)).fetchone()
    if not item:
        return redirect(url_for("asignaturas_list"))
    if request.method == "POST":
        nombre = request.form["nombre"].strip()
        descripcion = request.form.get("descripcion","").strip() or None
        db.execute("UPDATE asignaturas SET nombre=?, descripcion=? WHERE id=?", (nombre, descripcion, item_id))
        db.commit()
        return redirect(url_for("asignaturas_list"))
    return render_template("asignaturas_form.html", item=item)

@app.route("/admin/asignaturas/<int:item_id>/eliminar", methods=["POST"])
@login_required
def asignaturas_eliminar(item_id):
    db = get_db()
    db.execute("DELETE FROM asignaturas WHERE id=?", (item_id,))
    db.commit()
    return redirect(url_for("asignaturas_list"))

# Materiales
@app.route("/admin/materiales")
@login_required
def materiales_list():
    db = get_db()
    items = db.execute(
        """SELECT m.id, m.titulo, m.descripcion, m.url, m.creado_en,
                       c.nombre AS curso, a.nombre AS asignatura
               FROM materiales m
               JOIN cursos c ON c.id = m.curso_id
               JOIN asignaturas a ON a.id = m.asignatura_id
               ORDER BY m.id DESC""").fetchall()
    return render_template("materiales_list.html", items=items)

@app.route("/admin/materiales/nuevo", methods=["GET","POST"])
@login_required
def materiales_nuevo():
    db = get_db()
    cursos = db.execute("SELECT id, nombre FROM cursos ORDER BY nombre").fetchall()
    asignaturas = db.execute("SELECT id, nombre FROM asignaturas ORDER BY nombre").fetchall()
    if request.method == "POST":
        titulo = request.form["titulo"].strip()
        descripcion = request.form.get("descripcion","").strip() or None
        url = request.form.get("url","").strip() or None
        curso_id = int(request.form["curso_id"])
        asignatura_id = int(request.form["asignatura_id"])
        db.execute("""INSERT INTO materiales
                    (titulo, descripcion, url, asignatura_id, curso_id, creado_en)
                    VALUES (?,?,?,?,?,?)""",
                   (titulo, descripcion, url, asignatura_id, curso_id, datetime.utcnow().isoformat()))
        db.commit()
        return redirect(url_for("materiales_list"))
    return render_template("materiales_form.html", cursos=cursos, asignaturas=asignaturas, item=None)

@app.route("/admin/materiales/<int:item_id>/eliminar", methods=["POST"])
@login_required
def materiales_eliminar(item_id):
    db = get_db()
    db.execute("DELETE FROM materiales WHERE id=?", (item_id,))
    db.commit()
    return redirect(url_for("materiales_list"))

# Relaciones rápidas (matrículas e imparticiones) — mínimas para demo
@app.route("/admin/matriculas", methods=["GET","POST"])
@login_required
def matriculas():
    db = get_db()
    if request.method == "POST":
        alumno_id = int(request.form["alumno_id"])
        curso_id = int(request.form["curso_id"])
        try:
            db.execute("INSERT INTO matriculas (alumno_id, curso_id, fecha) VALUES (?,?,?)",
                       (alumno_id, curso_id, datetime.utcnow().isoformat()))
            db.commit()
        except sqlite3.IntegrityError:
            flash("La matrícula ya existe.", "error")
    data = db.execute(
        """SELECT m.id, a.nombre||' '||a.apellidos AS alumno, c.nombre AS curso, m.fecha
               FROM matriculas m
               JOIN alumnos a ON a.id = m.alumno_id
               JOIN cursos c  ON c.id = m.curso_id
               ORDER BY m.id DESC""").fetchall()
    alumnos = db.execute("SELECT id, nombre||' '||apellidos AS n FROM alumnos ORDER BY n").fetchall()
    cursos = db.execute("SELECT id, nombre FROM cursos ORDER BY nombre").fetchall()
    return render_template("matriculas.html", data=data, alumnos=alumnos, cursos=cursos)

@app.route("/admin/matriculas/<int:item_id>/eliminar", methods=["POST"])
@login_required
def matriculas_eliminar(item_id):
    db = get_db()
    db.execute("DELETE FROM matriculas WHERE id=?", (item_id,))
    db.commit()
    return redirect(url_for("matriculas"))

@app.route("/admin/imparticiones", methods=["GET","POST"])
@login_required
def imparticiones():
    db = get_db()
    if request.method == "POST":
        profesor_id = int(request.form["profesor_id"])
        asignatura_id = int(request.form["asignatura_id"])
        curso_id = int(request.form["curso_id"])
        try:
            db.execute("INSERT INTO imparticiones (profesor_id, asignatura_id, curso_id) VALUES (?,?,?)",
                       (profesor_id, asignatura_id, curso_id))
            db.commit()
        except sqlite3.IntegrityError:
            flash("La impartición ya existe.", "error")
    data = db.execute(
        """SELECT i.id,
                      p.nombre||' '||p.apellidos AS profesor,
                      a.nombre AS asignatura,
                      c.nombre AS curso
               FROM imparticiones i
               JOIN profesores p ON p.id = i.profesor_id
               JOIN asignaturas a ON a.id = i.asignatura_id
               JOIN cursos c ON c.id = i.curso_id
               ORDER BY i.id DESC""").fetchall()
    profesores = db.execute("SELECT id, nombre||' '||apellidos AS n FROM profesores ORDER BY n").fetchall()
    asignaturas = db.execute("SELECT id, nombre FROM asignaturas ORDER BY nombre").fetchall()
    cursos = db.execute("SELECT id, nombre FROM cursos ORDER BY nombre").fetchall()
    return render_template("imparticiones.html", data=data, profesores=profesores, asignaturas=asignaturas, cursos=cursos)

@app.route("/admin/imparticiones/<int:item_id>/eliminar", methods=["POST"])
@login_required
def imparticiones_eliminar(item_id):
    db = get_db()
    db.execute("DELETE FROM imparticiones WHERE id=?", (item_id,))
    db.commit()
    return redirect(url_for("imparticiones"))

if __name__ == "__main__":
    app.run(debug=True)
