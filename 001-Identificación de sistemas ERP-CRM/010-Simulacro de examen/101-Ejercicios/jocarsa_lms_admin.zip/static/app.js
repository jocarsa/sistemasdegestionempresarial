// espacio para mejoras JS (confirmaciones ya se hacen vía confirm())
